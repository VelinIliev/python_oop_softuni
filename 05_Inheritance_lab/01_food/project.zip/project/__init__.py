from project.food import Food
from project.fruit import Fruit

# food = Food("10")
# print(food.expiration_date)
# fruit = Fruit("banana")
# print(fruit.name)
# print(fruit.expiration_date)