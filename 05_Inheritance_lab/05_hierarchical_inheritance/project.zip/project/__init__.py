# from animal import Animal
# from dog import Dog
# from cat import Cat
#
# cat = Cat()
# dog = Dog()
#
# print(cat.meow())
# print(cat.eat())
# print(dog.bark())
# print(dog.eat())