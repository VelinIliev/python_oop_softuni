# from employee import Employee
# from person import Person
# from teacher import Teacher
#
# teacher = Teacher()
# print(teacher.get_fired())
# print(teacher.sleep())
# print(teacher.teach())