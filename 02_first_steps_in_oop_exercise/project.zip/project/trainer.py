from pokemon import Pokemon


class Trainer:
    def __init__(self, name: str):
        self.name = name
        self.pokemons = {}

    def add_pokemon(self, pokemon: Pokemon):
        if pokemon.name in self.pokemons:
            return f'This pokemon is already caught'
        else:
            self.pokemons[pokemon.name] = pokemon.health
            return f'Caught {pokemon.name} with health {pokemon.health}'

    def release_pokemon(self, pokemon_name: str):
        if pokemon_name in self.pokemons:
            del self.pokemons[pokemon_name]
            return f'You have released {pokemon_name}'
        else:
            return f'Pokemon is not caught'

    def trainer_data(self):
        return_string = ""
        return_string += f'Pokemon Trainer {self.name}\n'
        return_string += f'Pokemon count {len(self.pokemons)}\n'
        for name, health in self.pokemons.items():
            return_string += f'- {name} with health {health}'
        return return_string


pokemon = Pokemon("Pikachu", 90)
print(pokemon.pokemon_details())
trainer = Trainer("Ash")
print(trainer.add_pokemon(pokemon))
second_pokemon = Pokemon("Charizard", 110)
print(trainer.add_pokemon(second_pokemon))
print(trainer.add_pokemon(second_pokemon))
print(trainer.release_pokemon("Pikachu"))
print(trainer.release_pokemon("Pikachu"))
print(trainer.trainer_data())
