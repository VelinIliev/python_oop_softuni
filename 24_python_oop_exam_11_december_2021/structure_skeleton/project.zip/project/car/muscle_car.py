from project.car.car import Car


class MuscleCar(Car):
    min_speed_limit = 250
    max_speed_limit = 450